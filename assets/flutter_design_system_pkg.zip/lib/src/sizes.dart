class AppSizes {
  final double scaleFactor;
  final double xs;
  final double sm;
  final double md;
  final double lg;
  final double xl;
  final double buttonHeight;
  final double inputHeight;
  final double iconSize;
  final double radiusSm;
  final double radiusMd;
  final double radiusLg;

  const AppSizes({
    this.scaleFactor = 1.0,
    this.xs = 4,
    this.sm = 8,
    this.md = 16,
    this.lg = 24,
    this.xl = 32,
    this.buttonHeight = 48,
    this.inputHeight = 56,
    this.iconSize = 24,
    this.radiusSm = 6,
    this.radiusMd = 12,
    this.radiusLg = 20,
  });

  AppSizes scale(double factor) => AppSizes(
        scaleFactor: scaleFactor * factor,
        xs: xs * factor,
        sm: sm * factor,
        md: md * factor,
        lg: lg * factor,
        xl: xl * factor,
        buttonHeight: buttonHeight * factor,
        inputHeight: inputHeight * factor,
        iconSize: iconSize * factor,
        radiusSm: radiusSm * factor,
        radiusMd: radiusMd * factor,
        radiusLg: radiusLg * factor,
      );
}
