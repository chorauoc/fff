import 'package:flutter/material.dart';

class AppTypography {
  final String? fontFamily;
  final TextStyle h1;
  final TextStyle h2;
  final TextStyle h3;
  final TextStyle bodyLarge;
  final TextStyle body;
  final TextStyle caption;
  final TextStyle button;

  const AppTypography({
    this.fontFamily,
    required this.h1,
    required this.h2,
    required this.h3,
    required this.bodyLarge,
    required this.body,
    required this.caption,
    required this.button,
  });

  factory AppTypography.defaultTypography({String? fontFamily, double scale = 1.0}) => AppTypography(
        fontFamily: fontFamily,
        h1: TextStyle(fontSize: 32 * scale, fontWeight: FontWeight.w700),
        h2: TextStyle(fontSize: 24 * scale, fontWeight: FontWeight.w600),
        h3: TextStyle(fontSize: 18 * scale, fontWeight: FontWeight.w600),
        bodyLarge: TextStyle(fontSize: 16 * scale, fontWeight: FontWeight.w500),
        body: TextStyle(fontSize: 14 * scale, fontWeight: FontWeight.w400),
        caption: TextStyle(fontSize: 12 * scale, fontWeight: FontWeight.w300),
        button: TextStyle(fontSize: 14 * scale, fontWeight: FontWeight.w600),
      );
}
