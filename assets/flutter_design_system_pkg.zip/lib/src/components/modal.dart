import 'package:flutter/material.dart';
import '../config.dart';

Future<T?> showAppModal<T>(BuildContext context, {required Widget child}) {
  final sizes = DesignSystem.sizes;
  return showDialog<T>(
    context: context,
    builder: (_) => Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(sizes.radiusMd)),
      child: Padding(padding: EdgeInsets.all(sizes.md), child: child),
    ),
  );
}
