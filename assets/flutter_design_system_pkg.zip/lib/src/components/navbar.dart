import 'package:flutter/material.dart';
import '../config.dart';

class AppNavBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;

  const AppNavBar({Key? key, required this.title, this.actions}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = DesignSystem.colors;
    return AppBar(title: Text(title), backgroundColor: colors.primary, actions: actions);
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
