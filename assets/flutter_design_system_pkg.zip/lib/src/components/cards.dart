import 'package:flutter/material.dart';
import '../config.dart';

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;

  const AppCard({Key? key, required this.child, this.padding}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sizes = DesignSystem.sizes;
    final colors = DesignSystem.colors;
    return Card(
      color: colors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(sizes.radiusMd)),
      child: Padding(padding: padding ?? EdgeInsets.all(sizes.md), child: child),
    );
  }
}
