import 'package:flutter/material.dart';
import '../config.dart';

class AppChip extends StatelessWidget {
  final String label;
  final VoidCallback? onDeleted;

  const AppChip({Key? key, required this.label, this.onDeleted}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final colors = DesignSystem.colors;
    return Chip(
      label: Text(label),
      backgroundColor: colors.primary.withOpacity(0.12),
      onDeleted: onDeleted,
    );
  }
}
