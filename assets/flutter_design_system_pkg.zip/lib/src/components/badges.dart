import 'package:flutter/material.dart';
import '../config.dart';

class AppBadge extends StatelessWidget {
  final Widget child;
  final String value;

  const AppBadge({Key? key, required this.child, required this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sizes = DesignSystem.sizes;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          right: -6,
          top: -6,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: sizes.sm, vertical: sizes.xs),
            decoration: BoxDecoration(color: DesignSystem.colors.secondary, borderRadius: BorderRadius.circular(12)),
            child: Text(value, style: DesignSystem.typography.caption.copyWith(color: DesignSystem.colors.onSecondary)),
          ),
        )
      ],
    );
  }
}
