import 'package:flutter/material.dart';
import 'colors.dart';
import 'sizes.dart';
import 'typography.dart';

class DesignSystemConfig {
  final AppColors colors;
  final AppSizes sizes;
  final AppTypography typography;
  final Brightness brightness;

  const DesignSystemConfig({
    required this.colors,
    required this.sizes,
    required this.typography,
    this.brightness = Brightness.light,
  });
}

class DesignSystem {
  static late DesignSystemConfig _config;
  static bool _initialized = false;

  static void init(DesignSystemConfig cfg) {
    _config = cfg;
    _initialized = true;
  }

  static AppColors get colors {
    assert(_initialized, 'DesignSystem not initialized');
    return _config.colors;
  }

  static AppSizes get sizes {
    assert(_initialized, 'DesignSystem not initialized');
    return _config.sizes;
  }

  static AppTypography get typography {
    assert(_initialized, 'DesignSystem not initialized');
    return _config.typography;
  }

  static Brightness get brightness => _config.brightness;
}
