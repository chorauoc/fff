import 'package:flutter/material.dart';
import '../config.dart';
import '../responsive.dart';

enum ButtonKind { primary, secondary, ghost }

class AppButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final ButtonKind kind;
  final double? height;
  final EdgeInsets? padding;
  final double? radius;

  const AppButton({Key? key, required this.child, this.onPressed, this.kind = ButtonKind.primary, this.height, this.padding, this.radius}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Responsive.builder(context, (type, sizes) {
      final colors = DesignSystem.colors;
      final heightVal = height ?? sizes.buttonHeight;
      final radiusVal = radius ?? sizes.radiusMd;
      final paddingVal = padding ?? EdgeInsets.symmetric(horizontal: sizes.md);

      switch (kind) {
        case ButtonKind.primary:
          return ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              minimumSize: Size.fromHeight(heightVal),
              padding: paddingVal,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusVal)),
              backgroundColor: colors.primary,
              foregroundColor: colors.onPrimary,
            ),
            child: child,
          );
        case ButtonKind.secondary:
          return OutlinedButton(
            onPressed: onPressed,
            style: OutlinedButton.styleFrom(
              minimumSize: Size.fromHeight(heightVal),
              padding: paddingVal,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusVal)),
              side: BorderSide(color: colors.primary),
            ),
            child: child,
          );
        case ButtonKind.ghost:
          return TextButton(
            onPressed: onPressed,
            style: TextButton.styleFrom(minimumSize: Size.fromHeight(heightVal), padding: paddingVal),
            child: child,
          );
      }
    });
  }
}
