import 'package:flutter/material.dart';
import '../decorations.dart';
import '../config.dart';

class AppTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String? label;
  final String? hint;
  final bool obscureText;
  final Widget? prefix;
  final Widget? suffix;

  const AppTextField({Key? key, this.controller, this.label, this.hint, this.obscureText = false, this.prefix, this.suffix}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: DesignSystem.sizes.inputHeight,
      child: TextField(
        controller: controller,
        obscureText: obscureText,
        decoration: AppInputDecorations.outline(label: label, hint: hint, prefix: prefix, suffix: suffix),
      ),
    );
  }
}
