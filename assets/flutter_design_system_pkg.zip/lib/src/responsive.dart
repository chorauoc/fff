import 'package:flutter/widgets.dart';
import 'config.dart';

enum DeviceType { mobile, tablet, desktop }

class Responsive {
  static DeviceType deviceTypeFromWidth(double width) {
    if (width >= 1024) return DeviceType.desktop;
    if (width >= 600) return DeviceType.tablet;
    return DeviceType.mobile;
  }

  static T builder<T>(BuildContext context, T Function(DeviceType type, dynamic sizes) cb) {
    final width = MediaQuery.of(context).size.width;
    final type = deviceTypeFromWidth(width);
    final base = DesignSystem.sizes;
    final scaled = () {
      switch (type) {
        case DeviceType.mobile:
          return base;
        case DeviceType.tablet:
          return base.scale(1.25);
        case DeviceType.desktop:
          return base.scale(1.5);
      }
    }();
    return cb(type, scaled);
  }
}
