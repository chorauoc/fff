import 'package:flutter/material.dart';
import 'config.dart';
import 'sizes.dart';
import 'colors.dart';

class AppInputDecorations {
  static InputDecoration outline({
    required String? label,
    String? hint,
    Widget? prefix,
    Widget? suffix,
  }) {
    final colors = DesignSystem.colors;
    final sizes = DesignSystem.sizes;

    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: prefix,
      suffixIcon: suffix,
      contentPadding: EdgeInsets.symmetric(horizontal: sizes.md, vertical: sizes.sm),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(sizes.radiusMd)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(sizes.radiusMd),
        borderSide: BorderSide(color: colors.primary.withOpacity(0.2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(sizes.radiusMd),
        borderSide: BorderSide(color: colors.primary),
      ),
    );
  }
}
