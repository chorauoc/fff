import 'package:flutter/material.dart';

class AppColors {
  final Color primary;
  final Color primaryVariant;
  final Color secondary;
  final Color background;
  final Color surface;
  final Color error;
  final Color onPrimary;
  final Color onSecondary;
  final Color onBackground;
  final Color onSurface;
  final Color onError;

  const AppColors({
    required this.primary,
    required this.primaryVariant,
    required this.secondary,
    required this.background,
    required this.surface,
    required this.error,
    required this.onPrimary,
    required this.onSecondary,
    required this.onBackground,
    required this.onSurface,
    required this.onError,
  });

  factory AppColors.light() => const AppColors(
        primary: Color(0xFF0066FF),
        primaryVariant: Color(0xFF0044CC),
        secondary: Color(0xFFFFB300),
        background: Color(0xFFF8FAFF),
        surface: Color(0xFFFFFFFF),
        error: Color(0xFFB00020),
        onPrimary: Color(0xFFFFFFFF),
        onSecondary: Color(0xFF000000),
        onBackground: Color(0xFF0B1B2B),
        onSurface: Color(0xFF0B1B2B),
        onError: Color(0xFFFFFFFF),
      );

  factory AppColors.dark() => const AppColors(
        primary: Color(0xFF66A3FF),
        primaryVariant: Color(0xFF2C6BFF),
        secondary: Color(0xFFFFC857),
        background: Color(0xFF0B1220),
        surface: Color(0xFF0F1724),
        error: Color(0xFFCF6679),
        onPrimary: Color(0xFF001A3D),
        onSecondary: Color(0xFF001A3D),
        onBackground: Color(0xFFFFFFFF),
        onSurface: Color(0xFFFFFFFF),
        onError: Color(0xFF000000),
      );
}
