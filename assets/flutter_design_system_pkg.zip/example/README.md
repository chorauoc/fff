# Example Demo

Run this app from the `example` folder:

```bash
flutter run example/main.dart
```

The demo showcases:
- Theme runtime switching (light/dark)
- Buttons, inputs, cards, chips, badges, modal
