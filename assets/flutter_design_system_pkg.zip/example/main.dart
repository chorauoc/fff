import 'package:flutter/material.dart';
import 'package:flutter_design_system_pkg/flutter_design_system.dart';

void main() {
  final cfg = DesignSystemConfig(
    colors: AppColors.light(),
    sizes: AppSizes(),
    typography: AppTypography.defaultTypography(),
    brightness: Brightness.light,
  );
  DesignSystem.init(cfg);
  runApp(const DemoApp());
}

class DemoApp extends StatefulWidget {
  const DemoApp({Key? key}) : super(key: key);

  @override
  State<DemoApp> createState() => _DemoAppState();
}

class _DemoAppState extends State<DemoApp> {
  bool _dark = false;

  void _toggleTheme() {
    setState(() {
      _dark = !_dark;
      DesignSystem.init(DesignSystemConfig(
        colors: _dark ? AppColors.dark() : AppColors.light(),
        sizes: DesignSystem.sizes,
        typography: DesignSystem.typography,
        brightness: _dark ? Brightness.dark : Brightness.light,
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: DesignSystem.colors.primary, brightness: DesignSystem.brightness),
        useMaterial3: false,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Design System Demo'),
          actions: [IconButton(icon: Icon(Icons.brightness_6), onPressed: _toggleTheme)],
        ),
        body: Padding(
          padding: EdgeInsets.all(DesignSystem.sizes.md),
          child: ListView(
            children: [
              Text('Typography', style: DesignSystem.typography.h2),
              SizedBox(height: DesignSystem.sizes.sm),
              AppText('Body text example'),
              SizedBox(height: DesignSystem.sizes.sm),
              Text('Buttons', style: DesignSystem.typography.h3),
              SizedBox(height: DesignSystem.sizes.sm),
              Row(children: [
                Expanded(child: AppButton(child: Text('Primary'), onPressed: () {})),
                SizedBox(width: DesignSystem.sizes.sm),
                Expanded(child: AppButton(child: Text('Secondary'), kind: ButtonKind.secondary, onPressed: () {})),
              ]),
              SizedBox(height: DesignSystem.sizes.md),
              Text('Inputs', style: DesignSystem.typography.h3),
              SizedBox(height: DesignSystem.sizes.sm),
              AppTextField(label: 'Email', hint: 'you@example.com'),
              SizedBox(height: DesignSystem.sizes.md),
              Text('Components', style: DesignSystem.typography.h3),
              SizedBox(height: DesignSystem.sizes.sm),
              AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Card title', style: DesignSystem.typography.h3), SizedBox(height: DesignSystem.sizes.sm), Text('Some description')])),
              SizedBox(height: DesignSystem.sizes.sm),
              Wrap(spacing: DesignSystem.sizes.sm, children: [AppChip(label: 'Tag 1'), AppChip(label: 'Tag 2')]),
              SizedBox(height: DesignSystem.sizes.md),
              Row(children: [AppBadge(child: Icon(Icons.shopping_cart, size: DesignSystem.sizes.iconSize), value: '3')]),
              SizedBox(height: DesignSystem.sizes.md),
              ElevatedButton(
                onPressed: () => showAppModal(context, child: Column(mainAxisSize: MainAxisSize.min, children: [Text('Modal title', style: DesignSystem.typography.h2), SizedBox(height: DesignSystem.sizes.sm), Text('Modal content goes here')])),
                child: Text('Open Modal'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
