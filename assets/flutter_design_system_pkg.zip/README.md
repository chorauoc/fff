# Flutter Design System Package (Scaffold)

This repo is a scaffold for a reusable, responsive design system for Flutter.

Features:
- Token-based config (colors, sizes, typography)
- Responsive scaling (mobile/tablet/desktop)
- Common widgets: `AppText`, `AppButton`, `AppTextField`
- Extra components: cards, chips, navbar, badges, modal
- Theming runtime switching and example demo app (widget catalog)

How to use:
1. Copy `lib/src` into your project or publish as a package.
2. Initialize tokens at app start:
   ```dart
   DesignSystem.init(DesignSystemConfig(
     colors: AppColors.light(),
     sizes: AppSizes(),
     typography: AppTypography.defaultTypography(),
   ));
   ```
3. Wrap MaterialApp with `DesignSystemWidget` to enable runtime theme switching.

See `example/main.dart` for a runnable demo.
