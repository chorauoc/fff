import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../ui/app_shell.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/messages/messages_shell.dart';
import '../features/users/users_screen.dart';
import '../features/settings/settings_screen.dart';
import '../features/dashboard/animated_page.dart';

CustomTransitionPage _sharedAxis(Widget child, GoRouterState state) {
  return CustomTransitionPage(
    key: state.pageKey,
    child: child,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return FadeTransition(opacity: animation, child: child);
    },
  );
}

final GoRouter appRouter = GoRouter(
  initialLocation: '/dashboard',
  routes: [
    ShellRoute(
      builder: (context, state, child) => AppShell(body: child),
      routes: [
        GoRoute(
          path: '/dashboard',
          name: 'dashboard',
          pageBuilder: (context, state) => _sharedAxis(const DashboardScreen(), state),
        ),
        GoRoute(
          path: '/messages',
          name: 'messages',
          pageBuilder: (context, state) => _sharedAxis(const MessagesShell(), state),
        ),
        GoRoute(
          path: '/users',
          name: 'users',
          pageBuilder: (context, state) => _sharedAxis(const UsersScreen(), state),
        ),
        GoRoute(
          path: '/settings',
          name: 'settings',
          pageBuilder: (context, state) => _sharedAxis(const SettingsScreen(), state),
        ),
      ],
    ),
  ],
);
