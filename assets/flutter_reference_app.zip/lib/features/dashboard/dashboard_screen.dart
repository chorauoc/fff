import 'package:flutter/material.dart';
import '../../core/breakpoints.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    int crossAxisCount = 1;
    if (Breakpoints.isTablet(width)) crossAxisCount = 2;
    if (Breakpoints.isDesktop(width)) crossAxisCount = 4;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: GridView.count(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        children: const [
          _StatCard(title: 'Active Users', value: '1.2K'),
          _StatCard(title: 'Revenue', value: '\$58K'),
          _StatCard(title: 'Conversion', value: '5.4%'),
          _StatCard(title: 'New Signups', value: '320'),
        ],
      ),
    );
  }
}

class _StatCard extends StatefulWidget {
  final String title;
  final String value;
  const _StatCard({required this.title, required this.value});

  @override
  State<_StatCard> createState() => _StatCardState();
}

class _StatCardState extends State<_StatCard> {
  bool _hovering = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hovering = true),
      onExit: (_) => setState(() => _hovering = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        transform: _hovering ? Matrix4.translationValues(0, -3, 0) : Matrix4.identity(),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.white, boxShadow: _hovering ? [BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0,4))] : []),
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.title, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 8),
          Text(widget.value, style: Theme.of(context).textTheme.headlineMedium!.copyWith(color: Theme.of(context).colorScheme.primary)),
        ]),
      ),
    );
  }
}
