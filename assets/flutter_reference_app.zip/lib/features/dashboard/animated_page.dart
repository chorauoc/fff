import 'package:flutter/material.dart';

class AnimatedPage extends StatelessWidget {
  final Widget child;
  const AnimatedPage({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: child);
  }
}
