import 'package:flutter/material.dart';

class MessageList extends StatelessWidget {
  final void Function(String id) onTap;
  const MessageList({required this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    final items = List.generate(20, (i) => {'id': 'm\$i', 'title': 'Message \$i', 'subtitle': 'Subtitle \$i'});
    return ListView.separated(
      itemCount: items.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final it = items[index];
        return ListTile(
          title: Text(it['title']!),
          subtitle: Text(it['subtitle']!),
          onTap: () => onTap(it['id']!),
        );
      },
    );
  }
}
