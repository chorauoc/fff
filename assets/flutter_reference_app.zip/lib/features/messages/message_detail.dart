import 'package:flutter/material.dart';

class MessageDetail extends StatelessWidget {
  final String id;
  final VoidCallback? onBack;
  const MessageDetail({required this.id, this.onBack, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: onBack != null ? AppBar(title: Text('Message Detail'), leading: BackButton(onPressed: onBack)) : null,
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Message: \$id', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          const Text('This is the body of the message.'),
        ]),
      ),
    );
  }
}
