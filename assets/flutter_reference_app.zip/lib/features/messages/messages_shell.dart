import 'package:flutter/material.dart';
import '../../core/breakpoints.dart';
import 'message_list.dart';
import 'message_detail.dart';

class MessagesShell extends StatefulWidget {
  const MessagesShell({super.key});

  @override
  State<MessagesShell> createState() => _MessagesShellState();
}

class _MessagesShellState extends State<MessagesShell> {
  String? _selectedId;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    if (Breakpoints.isMobile(width)) {
      return Navigator(
        pages: [
          MaterialPage(child: MessageList(onTap: (id) => setState(() => _selectedId = id))),
          if (_selectedId != null) MaterialPage(child: MessageDetail(id: _selectedId!, onBack: () => setState(() => _selectedId = null))),
        ],
        onPopPage: (route, result) => route.didPop(result),
      );
    }

    return Row(
      children: [
        Expanded(flex: 1, child: MessageList(onTap: (id) => setState(() => _selectedId = id))),
        const VerticalDivider(width: 1),
        Expanded(flex: 2, child: _selectedId == null ? const Center(child: Text('Select a message')) : MessageDetail(id: _selectedId!)),
      ],
    );
  }
}
