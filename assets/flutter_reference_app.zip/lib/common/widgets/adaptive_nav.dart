import 'package:flutter/material.dart';
import '../../core/breakpoints.dart';

class AdaptiveNavigation extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  const AdaptiveNavigation({super.key, required this.selectedIndex, required this.onDestinationSelected});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    if (Breakpoints.isMobile(width)) {
      return NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: onDestinationSelected,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.mail), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Users'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      );
    } else if (Breakpoints.isTablet(width)) {
      return NavigationRail(
        selectedIndex: selectedIndex,
        onDestinationSelected: onDestinationSelected,
        destinations: const [
          NavigationRailDestination(icon: Icon(Icons.dashboard), label: Text('Dashboard')),
          NavigationRailDestination(icon: Icon(Icons.mail), label: Text('Messages')),
          NavigationRailDestination(icon: Icon(Icons.people), label: Text('Users')),
          NavigationRailDestination(icon: Icon(Icons.settings), label: Text('Settings')),
        ],
      );
    } else {
      // Desktop drawer-style vertical menu (used in AppShell as a side drawer)
      return const SizedBox.shrink();
    }
  }
}
