import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/breakpoints.dart';
import '../common/widgets/adaptive_nav.dart';

class AppShell extends StatelessWidget {
  final Widget body;
  const AppShell({super.key, required this.body});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    if (Breakpoints.isDesktop(width)) {
      return Scaffold(
        body: Row(
          children: [
            const _DesktopSidebar(),
            Expanded(
              child: Column(
                children: [
                  const _TopBar(),
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: body,
                    ),
                  ),
                  const _Footer(),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (Breakpoints.isTablet(width)) {
      return Scaffold(
        body: Column(
          children: [
            const _TopBar(),
            Expanded(
              child: Row(
                children: [
                  const _CollapsedSidebar(),
                  Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 250), child: body)),
                ],
              ),
            ),
            const _Footer(),
          ],
        ),
      );
    }

    // Mobile
    return Scaffold(
      appBar: AppBar(title: const Text('Reference App')),
      body: body,
      bottomNavigationBar: AdaptiveNavigation(
        selectedIndex: _selectedIndexFromLocation(GoRouterState.of(context).uri.toString()),
        onDestinationSelected: (i) => _onNavSelect(context, i),
      ),
    );
  }

  static int _selectedIndexFromLocation(String location) {
    if (location.contains('messages')) return 1;
    if (location.contains('users')) return 2;
    if (location.contains('settings')) return 3;
    return 0;
  }

  static void _onNavSelect(BuildContext context, int i) {
    switch (i) {
      case 0:
        context.go('/dashboard');
        break;
      case 1:
        context.go('/messages');
        break;
      case 2:
        context.go('/users');
        break;
      case 3:
        context.go('/settings');
        break;
    }
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      color: Theme.of(context).colorScheme.surface,
      child: Row(
        children: [
          const Text('Reference App', style: TextStyle(fontWeight: FontWeight.bold)),
          const Spacer(),
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          IconButton(icon: const Icon(Icons.notifications_outlined), onPressed: () {}),
          const CircleAvatar(child: Icon(Icons.person)),
        ],
      ),
    );
  }
}

class _DesktopSidebar extends StatefulWidget {
  const _DesktopSidebar();

  @override
  State<_DesktopSidebar> createState() => _DesktopSidebarState();
}

class _DesktopSidebarState extends State<_DesktopSidebar> {
  bool _collapsed = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: _collapsed ? 70 : 240,
      color: Theme.of(context).colorScheme.surfaceVariant,
      child: Column(
        children: [
          IconButton(icon: Icon(_collapsed ? Icons.menu : Icons.close), onPressed: () => setState(() => _collapsed = !_collapsed)),
          Expanded(
            child: ListView(
              children: [
                _SidebarItem(icon: Icons.dashboard, label: 'Dashboard', collapsed: _collapsed, route: '/dashboard'),
                _SidebarItem(icon: Icons.mail, label: 'Messages', collapsed: _collapsed, route: '/messages'),
                _SidebarItem(icon: Icons.people, label: 'Users', collapsed: _collapsed, route: '/users'),
                _SidebarItem(icon: Icons.settings, label: 'Settings', collapsed: _collapsed, route: '/settings'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SidebarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool collapsed;
  final String route;
  const _SidebarItem({required this.icon, required this.label, required this.collapsed, required this.route});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon),
      title: collapsed ? null : Text(label),
      onTap: () => context.go(route),
    );
  }
}

class _CollapsedSidebar extends StatelessWidget {
  const _CollapsedSidebar();

  @override
  Widget build(BuildContext context) {
    return NavigationRail(
      extended: false,
      selectedIndex: 0,
      onDestinationSelected: (i) {},
      destinations: const [
        NavigationRailDestination(icon: Icon(Icons.dashboard_outlined), label: Text('Dashboard')),
        NavigationRailDestination(icon: Icon(Icons.mail_outline), label: Text('Messages')),
        NavigationRailDestination(icon: Icon(Icons.settings_outlined), label: Text('Settings')),
      ],
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer();

  @override
  Widget build(BuildContext context) {
    return Container(height: 50, alignment: Alignment.center, color: Theme.of(context).colorScheme.surfaceVariant, child: Text('© ${DateTime.now().year} MyCompany'));
  }
}
