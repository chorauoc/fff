# Flutter Reference App

This is a compact reference project demonstrating:

- Responsive AppShell (desktop/tablet/mobile)
- GoRouter ShellRoute with persistent shell
- Adaptive navigation (BottomNav, NavigationRail, Sidebar)
- Multi-pane Messages shell (single-pane on mobile)
- Riverpod integration (project scaffolded to add providers)
- Animated transitions, skeletons, and hover effects

How to run:
1. Install Flutter SDK (stable channel).
2. Copy this project into a new Flutter project folder.
3. Run `flutter pub get`.
4. Run `flutter run -d chrome` for web, or `flutter run` for mobile.

Notes:
- This project is intentionally compact to focus on layout & routing patterns.
- Add your own providers, API clients and feature code as needed.
